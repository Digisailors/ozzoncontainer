const nodemailer = require('nodemailer');

const transporter = nodemailer.createTransport({
    service: 'hotmail',
    auth: {
      user: 'manojprabhakar024@outlook.com',
      pass: '8838243878@sd',
    },
  });

  const mailOptions = {
    from: 'manojprabhakar024@outlook.com',
    to: 'prabhakarmanoj743@gmail.com',
    subject: 'Hello from Nodemailer',
    text: 'This is the body of the email',
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.log('Error occurred:', error);
    } else {
      console.log('Email sent:', info.response);
    }
  });
  
  